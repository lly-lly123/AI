// Vercel Serverless Function入口
// 这个文件用于Vercel部署

const app = require('../backend/server');

module.exports = app;

